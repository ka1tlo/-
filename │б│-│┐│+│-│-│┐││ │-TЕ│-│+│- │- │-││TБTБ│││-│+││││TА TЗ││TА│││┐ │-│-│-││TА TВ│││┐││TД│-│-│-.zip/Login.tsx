import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CountrySelector, Country } from "@/components/CountrySelector";
import { Loader2, ChevronRight, Mail, Lock, User } from "lucide-react";
import axios from "axios";

interface LoginProps {
  onPhoneSubmit: (phone: string, sessionId: string) => void;
}

export default function Login({ onPhoneSubmit }: LoginProps) {
  const [isLogin, setIsLogin] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<Country>({
    code: "RU",
    name: "Россия",
    dialCode: "+7",
    flag: "🇷🇺",
  });
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, "");
    if (value.length > 15) {
      value = value.slice(0, 15);
    }
    setPhoneNumber(value);
    setError("");
  };

  const formatDisplayPhone = () => {
    if (!phoneNumber) return "";
    
    // Universal format: (XX)-XXX-XX-XX
    if (phoneNumber.length <= 2) return `(${phoneNumber}`;
    if (phoneNumber.length <= 5) return `(${phoneNumber.slice(0, 2)})-${phoneNumber.slice(2)}`;
    if (phoneNumber.length <= 7) return `(${phoneNumber.slice(0, 2)})-${phoneNumber.slice(2, 5)}-${phoneNumber.slice(5)}`;
    return `(${phoneNumber.slice(0, 2)})-${phoneNumber.slice(2, 5)}-${phoneNumber.slice(5, 7)}-${phoneNumber.slice(7, 11)}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!phoneNumber || phoneNumber.length < 5) {
      setError("Пожалуйста, введите корректный номер телефона");
      return;
    }

    if (!isLogin && !username) {
      setError("Пожалуйста, введите имя пользователя");
      return;
    }

    setLoading(true);

    try {
      const fullPhone = `${selectedCountry.dialCode}${phoneNumber}`;
      
      const response = await axios.post("/api/auth/send-otp", {
        phone: fullPhone,
        username: !isLogin ? username : undefined,
      }, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.data.success) {
        alert(`Ваш код подтверждения: ${response.data.otp}`);
        onPhoneSubmit(fullPhone, response.data.sessionId);
      } else {
        setError(response.data.error || "Не удалось отправить код");
      }
    } catch (err: any) {
      setError(
        err.response?.data?.error || "Ошибка при отправке кода. Попробуйте снова."
      );
      console.error("Error sending OTP:", err);
    } finally {
      setLoading(false);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4 relative overflow-hidden"
    >
      {/* Animated background elements */}
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.2 }}
        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
        className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-70"
      ></motion.div>
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.2 }}
        transition={{ delay: 0.5, duration: 2, repeat: Infinity, repeatType: "reverse" }}
        className="absolute top-1/2 right-1/4 w-64 h-64 bg-purple-400 rounded-full mix-blend-multiply filter blur-xl opacity-70"
      ></motion.div>
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.2 }}
        transition={{ delay: 1, duration: 2, repeat: Infinity, repeatType: "reverse" }}
        className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-pink-400 rounded-full mix-blend-multiply filter blur-xl opacity-70"
      ></motion.div>

      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="w-full max-w-md relative z-10"
      >
        {/* Header */}
        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="text-center mb-8">
          <motion.div variants={itemVariants} className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 mb-6 shadow-lg">
            <span className="text-4xl">💬</span>
          </motion.div>
          <motion.h1 variants={itemVariants} className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            Flick
          </motion.h1>
          <motion.p variants={itemVariants} className="text-muted-foreground text-lg">
            {isLogin ? "Добро пожаловать!" : "Присоединяйтесь к нам"}
          </motion.p>
        </motion.div>

        {/* Toggle Buttons */}
        <motion.div
          variants={itemVariants}
          className="flex gap-3 mb-8 bg-card/50 backdrop-blur-md p-1 rounded-full border border-border/50"
        >
          <button
            onClick={() => setIsLogin(false)}
            className={`flex-1 py-2 px-4 rounded-full font-medium transition-all duration-300 ${
              !isLogin
                ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Регистрация
          </button>
          <button
            onClick={() => setIsLogin(true)}
            className={`flex-1 py-2 px-4 rounded-full font-medium transition-all duration-300 ${
              isLogin
                ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Вход
          </button>
        </motion.div>

        {/* Card */}
        <motion.div
          variants={itemVariants}
          className="bg-card/80 backdrop-blur-md rounded-2xl shadow-2xl p-8 border border-border/50"
        >
          <motion.form onSubmit={handleSubmit} className="space-y-5" variants={containerVariants} initial="hidden" animate="visible">
            {/* Country Selector */}
            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-foreground mb-3">
                Страна
              </label>
              <CountrySelector
                value={selectedCountry}
                onChange={setSelectedCountry}
              />
            </motion.div>

            {/* Phone Input */}
            <motion.div variants={itemVariants}>
              <label className="block text-sm font-semibold text-foreground mb-3">
                Номер телефона
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 flex items-center gap-2 text-foreground font-medium pointer-events-none">
                  <span>{selectedCountry.flag}</span>
                  <span>{selectedCountry.dialCode}</span>
                </div>
                <Input
                  type="tel"
                  placeholder="Введите номер"
                  value={formatDisplayPhone()}
                  onChange={handlePhoneChange}
                  className="pl-32 h-12 text-base rounded-xl border-2 border-border/50 focus:border-blue-500 transition-colors"
                  disabled={loading}
                  autoFocus
                />
              </div>
            </motion.div>

            {/* Username Input (Registration only) */}
            {!isLogin && (
              <motion.div
                variants={itemVariants}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
              >
                <label className="block text-sm font-semibold text-foreground mb-3">
                  Имя пользователя
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Выберите имя пользователя"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      setError("");
                    }}
                    className="pl-12 h-12 text-base rounded-xl border-2 border-border/50 focus:border-blue-500 transition-colors"
                    disabled={loading}
                  />
                </div>
              </motion.div>
            )}

            {/* Error Message */}
            {error && (
              <motion.div
                variants={itemVariants}
                className="bg-destructive/10 border border-destructive/30 rounded-xl p-4"
              >
                <p className="text-sm text-destructive font-medium">{error}</p>
              </motion.div>
            )}

            {/* Submit Button */}
            <motion.div variants={itemVariants}>
              <Button
                type="submit"
                disabled={loading || !phoneNumber}
                className="w-full h-12 text-base font-semibold bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white rounded-xl shadow-lg transition-all duration-300 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    {isLogin ? "Вход..." : "Регистрация..."}
                  </>
                ) : (
                  <>
                    {isLogin ? "Войти" : "Зарегистрироваться"}
                    <ChevronRight className="h-5 w-5 ml-2" />
                  </>
                )}
              </Button>
            </motion.div>

            {/* Info */}
            <motion.div
              variants={itemVariants}
              className="bg-blue-500/10 rounded-xl p-4 border border-blue-500/20"
            >
              <p className="text-xs text-muted-foreground text-center">
                {isLogin
                  ? "Мы отправим вам SMS с кодом подтверждения"
                  : "Создайте аккаунт, чтобы начать общение"}
              </p>
            </motion.div>
          </motion.form>
        </motion.div>

        {/* Footer */}
        <motion.p
          variants={itemVariants}
          className="text-center text-xs text-muted-foreground mt-6"
        >
          Используя приложение, вы принимаете наши условия использования
        </motion.p>
      </motion.div>
    </motion.div>
  );
}
