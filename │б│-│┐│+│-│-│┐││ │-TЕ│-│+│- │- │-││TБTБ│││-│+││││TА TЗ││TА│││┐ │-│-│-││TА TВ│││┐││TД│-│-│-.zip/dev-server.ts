import express, { Request, Response } from "express";
import { createServer } from "http";

// In-memory storage for OTP codes (in production, use database)
interface OTPSession {
  code: string;
  phone: string;
  createdAt: number;
  attempts: number;
}

const otpSessions = new Map<string, OTPSession>();
const MAX_ATTEMPTS = 5;
const OTP_EXPIRY = 10 * 60 * 1000; // 10 minutes
const OTP_LENGTH = 6;

// Generate random OTP code
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Validate phone number format - более мягкая валидация
function isValidPhone(phone: string): boolean {
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, "");
  // Требуем минимум 7 цифр (даже для коротких номеров)
  return digits.length >= 7;
}

// Очистить номер телефона
function cleanPhone(phone: string): string {
  return phone.replace(/\D/g, "");
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // CORS
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // API Routes

  // Send OTP to phone number
  app.post("/api/auth/send-otp", (req: Request, res: Response) => {
    try {
      let { phone } = req.body;

      console.log(`\n📞 Received phone: ${phone}`);

      if (!phone) {
        console.log("❌ Error: Phone number is required");
        return res.status(400).json({ error: "Phone number is required" });
      }

      // Очистить номер
      phone = String(phone).trim();
      console.log(`📞 Cleaned phone: ${phone}`);

      if (!isValidPhone(phone)) {
        console.log(`❌ Error: Invalid phone format: ${phone}`);
        return res.status(400).json({ error: "Invalid phone number format" });
      }

      // Generate OTP
      const otp = generateOTP();
      const sessionId = Math.random().toString(36).substring(2, 15);

      // Store OTP session
      otpSessions.set(sessionId, {
        code: otp,
        phone,
        createdAt: Date.now(),
        attempts: 0,
      });

      // Log OTP with beautiful formatting
      console.log("═══════════════════════════════════════════════════════");
      console.log("✅ OTP GENERATED SUCCESSFULLY");
      console.log("═══════════════════════════════════════════════════════");
      console.log(`📱 Phone Number: ${phone}`);
      console.log(`🔐 OTP Code: ${otp}`);
      console.log(`🆔 Session ID: ${sessionId}`);
      console.log(`⏰ Expires in: 10 minutes`);
      console.log("═══════════════════════════════════════════════════════\n");

      // Return session ID to client with code visible
      res.json({
        success: true,
        sessionId,
        code: otp, // Отправляем код в ответе для разработки
        phone,
        message: `OTP sent to ${phone}. Code: ${otp}`,
      });
    } catch (error) {
      console.error("❌ Error sending OTP:", error);
      res.status(500).json({ error: "Failed to send OTP" });
    }
  });

  // Verify OTP code
  app.post("/api/auth/verify-otp", (req: Request, res: Response) => {
    try {
      const { sessionId, code } = req.body;

      console.log(`\n🔍 Verifying OTP...`);
      console.log(`Session ID: ${sessionId}`);
      console.log(`Code entered: ${code}`);

      if (!sessionId || !code) {
        console.log("❌ Error: Missing sessionId or code");
        return res.status(400).json({ error: "Session ID and code are required" });
      }

      const session = otpSessions.get(sessionId);

      if (!session) {
        console.log("❌ Error: Invalid or expired session");
        return res.status(400).json({ error: "Invalid or expired session" });
      }

      // Check if OTP has expired
      if (Date.now() - session.createdAt > OTP_EXPIRY) {
        otpSessions.delete(sessionId);
        console.log("❌ Error: OTP has expired");
        return res.status(400).json({ error: "OTP has expired" });
      }

      // Check attempts
      if (session.attempts >= MAX_ATTEMPTS) {
        otpSessions.delete(sessionId);
        console.log("❌ Error: Too many attempts");
        return res.status(400).json({ error: "Too many attempts. Please request a new OTP." });
      }

      // Verify code
      if (code === session.code) {
        const phone = session.phone;
        otpSessions.delete(sessionId);

        // Create user session (in production, use proper session management)
        const token = Math.random().toString(36).substring(2, 15);

        console.log("═══════════════════════════════════════════════════════");
        console.log("✅ OTP VERIFIED SUCCESSFULLY");
        console.log("═══════════════════════════════════════════════════════");
        console.log(`📱 Phone: ${phone}`);
        console.log(`🔑 Token: ${token}`);
        console.log("═══════════════════════════════════════════════════════\n");

        res.json({
          success: true,
          token,
          phone,
          message: "Phone verified successfully",
        });
      } else {
        session.attempts++;
        const attemptsLeft = MAX_ATTEMPTS - session.attempts;
        console.log(`❌ Wrong code. Attempts left: ${attemptsLeft}`);
        res.status(400).json({
          error: "Invalid OTP code",
          attemptsLeft,
        });
      }
    } catch (error) {
      console.error("❌ Error verifying OTP:", error);
      res.status(500).json({ error: "Failed to verify OTP" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req: Request, res: Response) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  const port = 5173; // Different port for dev server

  server.listen(port, () => {
    console.log(`\n🚀 Dev API Server running on http://localhost:${port}/`);
    console.log(`📱 SMS verification API ready`);
    console.log(`✅ Server is listening for requests...\n`);
  });
}

startServer().catch(console.error);
