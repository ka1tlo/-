export type Language = "ru" | "en" | "es" | "fr" | "de";

export type TranslationKey = 
  | "appName"
  | "chats"
  | "contacts"
  | "profile"
  | "settings"
  | "archive"
  | "searchChats"
  | "searchByUsername"
  | "addContact"
  | "createGroup"
  | "newAccount"
  | "savedMessages"
  | "myStories"
  | "online"
  | "offline"
  | "username"
  | "name"
  | "phone"
  | "bio"
  | "about"
  | "language"
  | "saveChanges"
  | "restrictions"
  | "privacy"
  | "notifications"
  | "blockedUsers"
  | "selectLanguage"
  | "userNotFound"
  | "message"
  | "send"
  | "edit"
  | "delete"
  | "cancel"
  | "allowMessages"
  | "allowCalls"
  | "allowStories"
  | "notifications_title"
  | "sound"
  | "vibration"
  | "preview"
  | "privacy_title"
  | "twoFA"
  | "showStatus"
  | "encryption"
  | "general_title"
  | "compactView"
  | "animations"
  | "storage_title"
  | "clearCache"
  | "dataUsage";

const translations: Record<Language, Record<TranslationKey, string>> = {
  ru: {
    appName: "Flick",
    chats: "Чаты",
    contacts: "Контакты",
    profile: "Профиль",
    settings: "Настройки",
    archive: "Архив",
    searchChats: "Поиск чатов...",
    searchByUsername: "Поиск по юзернейму...",
    addContact: "Добавить",
    createGroup: "Создать группу",
    newAccount: "Новый аккаунт",
    savedMessages: "Сохранённые сообщения",
    myStories: "Мои истории",
    online: "онлайн",
    offline: "офлайн",
    username: "Юзернейм",
    name: "Имя",
    phone: "Телефон",
    bio: "Биография",
    about: "О себе",
    language: "Язык",
    saveChanges: "Сохранить изменения",
    restrictions: "Ограничения",
    privacy: "Конфиденциальность",
    notifications: "Уведомления",
    blockedUsers: "Заблокированные пользователи",
    selectLanguage: "Выберите язык",
    userNotFound: "Пользователь не найден",
    message: "Сообщение",
    send: "Отправить",
    edit: "Редактировать",
    delete: "Удалить",
    cancel: "Отмена",
    allowMessages: "Разрешить сообщения",
    allowCalls: "Разрешить звонки",
    allowStories: "Разрешить истории",
    notifications_title: "Уведомления",
    sound: "Звук",
    vibration: "Вибрация",
    preview: "Превью сообщений",
    privacy_title: "Конфиденциальность",
    twoFA: "Двухфакторная аутентификация",
    showStatus: "Показывать статус онлайн",
    encryption: "Сквозное шифрование",
    general_title: "Общие",
    compactView: "Компактный вид",
    animations: "Анимации",
    storage_title: "Данные и память",
    clearCache: "Очистить кеш",
    dataUsage: "Использование памяти",
  },
  en: {
    appName: "Flick",
    chats: "Chats",
    contacts: "Contacts",
    profile: "Profile",
    settings: "Settings",
    archive: "Archive",
    searchChats: "Search chats...",
    searchByUsername: "Search by username...",
    addContact: "Add",
    createGroup: "Create group",
    newAccount: "New account",
    savedMessages: "Saved messages",
    myStories: "My stories",
    online: "online",
    offline: "offline",
    username: "Username",
    name: "Name",
    phone: "Phone",
    bio: "Bio",
    about: "About",
    language: "Language",
    saveChanges: "Save changes",
    restrictions: "Restrictions",
    privacy: "Privacy",
    notifications: "Notifications",
    blockedUsers: "Blocked users",
    selectLanguage: "Select language",
    userNotFound: "User not found",
    message: "Message",
    send: "Send",
    edit: "Edit",
    delete: "Delete",
    cancel: "Cancel",
    allowMessages: "Allow messages",
    allowCalls: "Allow calls",
    allowStories: "Allow stories",
    notifications_title: "Notifications",
    sound: "Sound",
    vibration: "Vibration",
    preview: "Message preview",
    privacy_title: "Privacy",
    twoFA: "Two-factor authentication",
    showStatus: "Show online status",
    encryption: "End-to-end encryption",
    general_title: "General",
    compactView: "Compact view",
    animations: "Animations",
    storage_title: "Data & Storage",
    clearCache: "Clear cache",
    dataUsage: "Storage usage",
  },
  es: {
    appName: "Flick",
    chats: "Chats",
    contacts: "Contactos",
    profile: "Perfil",
    settings: "Configuración",
    archive: "Archivo",
    searchChats: "Buscar chats...",
    searchByUsername: "Buscar por nombre de usuario...",
    addContact: "Añadir",
    createGroup: "Crear grupo",
    newAccount: "Nueva cuenta",
    savedMessages: "Mensajes guardados",
    myStories: "Mis historias",
    online: "en línea",
    offline: "desconectado",
    username: "Nombre de usuario",
    name: "Nombre",
    phone: "Teléfono",
    bio: "Biografía",
    about: "Acerca de",
    language: "Idioma",
    saveChanges: "Guardar cambios",
    restrictions: "Restricciones",
    privacy: "Privacidad",
    notifications: "Notificaciones",
    blockedUsers: "Usuarios bloqueados",
    selectLanguage: "Seleccionar idioma",
    userNotFound: "Usuario no encontrado",
    message: "Mensaje",
    send: "Enviar",
    edit: "Editar",
    delete: "Eliminar",
    cancel: "Cancelar",
    allowMessages: "Permitir mensajes",
    allowCalls: "Permitir llamadas",
    allowStories: "Permitir historias",
    notifications_title: "Notificaciones",
    sound: "Sonido",
    vibration: "Vibración",
    preview: "Vista previa de mensajes",
    privacy_title: "Privacidad",
    twoFA: "Autenticación de dos factores",
    showStatus: "Mostrar estado en línea",
    encryption: "Cifrado de extremo a extremo",
    general_title: "General",
    compactView: "Vista compacta",
    animations: "Animaciones",
    storage_title: "Datos y almacenamiento",
    clearCache: "Borrar caché",
    dataUsage: "Uso de almacenamiento",
  },
  fr: {
    appName: "Flick",
    chats: "Chats",
    contacts: "Contacts",
    profile: "Profil",
    settings: "Paramètres",
    archive: "Archive",
    searchChats: "Rechercher des chats...",
    searchByUsername: "Rechercher par nom d'utilisateur...",
    addContact: "Ajouter",
    createGroup: "Créer un groupe",
    newAccount: "Nouveau compte",
    savedMessages: "Messages enregistrés",
    myStories: "Mes histoires",
    online: "en ligne",
    offline: "hors ligne",
    username: "Nom d'utilisateur",
    name: "Nom",
    phone: "Téléphone",
    bio: "Biographie",
    about: "À propos",
    language: "Langue",
    saveChanges: "Enregistrer les modifications",
    restrictions: "Restrictions",
    privacy: "Confidentialité",
    notifications: "Notifications",
    blockedUsers: "Utilisateurs bloqués",
    selectLanguage: "Sélectionner la langue",
    userNotFound: "Utilisateur non trouvé",
    message: "Message",
    send: "Envoyer",
    edit: "Modifier",
    delete: "Supprimer",
    cancel: "Annuler",
    allowMessages: "Autoriser les messages",
    allowCalls: "Autoriser les appels",
    allowStories: "Autoriser les histoires",
    notifications_title: "Notifications",
    sound: "Son",
    vibration: "Vibration",
    preview: "Aperçu des messages",
    privacy_title: "Confidentialité",
    twoFA: "Authentification à deux facteurs",
    showStatus: "Afficher l'état en ligne",
    encryption: "Chiffrement de bout en bout",
    general_title: "Général",
    compactView: "Vue compacte",
    animations: "Animations",
    storage_title: "Données et stockage",
    clearCache: "Effacer le cache",
    dataUsage: "Utilisation du stockage",
  },
  de: {
    appName: "Flick",
    chats: "Chats",
    contacts: "Kontakte",
    profile: "Profil",
    settings: "Einstellungen",
    archive: "Archiv",
    searchChats: "Chats durchsuchen...",
    searchByUsername: "Nach Benutzername suchen...",
    addContact: "Hinzufügen",
    createGroup: "Gruppe erstellen",
    newAccount: "Neues Konto",
    savedMessages: "Gespeicherte Nachrichten",
    myStories: "Meine Geschichten",
    online: "online",
    offline: "offline",
    username: "Benutzername",
    name: "Name",
    phone: "Telefon",
    bio: "Biografie",
    about: "Über",
    language: "Sprache",
    saveChanges: "Änderungen speichern",
    restrictions: "Einschränkungen",
    privacy: "Datenschutz",
    notifications: "Benachrichtigungen",
    blockedUsers: "Blockierte Benutzer",
    selectLanguage: "Sprache wählen",
    userNotFound: "Benutzer nicht gefunden",
    message: "Nachricht",
    send: "Senden",
    edit: "Bearbeiten",
    delete: "Löschen",
    cancel: "Abbrechen",
    allowMessages: "Nachrichten zulassen",
    allowCalls: "Anrufe zulassen",
    allowStories: "Geschichten zulassen",
    notifications_title: "Benachrichtigungen",
    sound: "Ton",
    vibration: "Vibration",
    preview: "Nachrichtenvorschau",
    privacy_title: "Datenschutz",
    twoFA: "Zwei-Faktor-Authentifizierung",
    showStatus: "Online-Status anzeigen",
    encryption: "End-to-End-Verschlüsselung",
    general_title: "Allgemein",
    compactView: "Kompakte Ansicht",
    animations: "Animationen",
    storage_title: "Daten und Speicher",
    clearCache: "Cache löschen",
    dataUsage: "Speichernutzung",
  },
};

export function getTranslation(language: Language, key: TranslationKey): string {
  return translations[language]?.[key] || translations.ru[key] || key;
}
